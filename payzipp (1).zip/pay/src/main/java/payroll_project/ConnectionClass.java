/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package payroll_project;
import java.sql.*;
/**
 *
 * @author shreya jadhav
 */
public class ConnectionClass {
    Connection con;
    Statement stm;
    ConnectionClass()
    {
        try
        {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con=DriverManager.getConnection("Jdbc:mysql://localhost:3360/login","root","shreya@0000");
            stm=con.createStatement();
            if(con.isClosed())
            {
                System.out.println("Connection Closed");
            }
            else
            {
                System.out.println("Connection create");
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    public static void main(String args[])
    {
        new ConnectionClass();
    }
}
