/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package payroll_project;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 *
 * @author shreya jadhav
 */
public class home_payroll extends JFrame implements ActionListener {
       
        Font f;
      home_payroll() {
          super("HOME PAGE");
          setSize(1600,690);
          setLocation(1,1);
           f =new Font("Arial",Font.BOLD,14);
           
           JMenuBar mb =new JMenuBar();
           JMenu m1=new JMenu("Employee");
           JMenu m2=new JMenu("Update");
           JMenu m3=new JMenu("Attendence");
           JMenu m4=new JMenu("Exit");
           
           m1.setFont(f);
           m2.setFont(f);
           m3.setFont(f);
           m4.setFont(f);
           
           JMenuItem mt1=new JMenuItem("New Employee");
           mt1.setMnemonic('Y');
           mt1.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Y,ActionEvent.CTRL_MASK));
           mt1.addActionListener(this);
           
            JMenuItem mt2=new JMenuItem("Salary");
           mt2.setMnemonic('S');
           mt2.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S,ActionEvent.CTRL_MASK));
           mt2.addActionListener(this);
           
            JMenuItem mt3=new JMenuItem("List Employee");
           mt3.setMnemonic('I');
           mt3.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_I,ActionEvent.CTRL_MASK));
           mt3.addActionListener(this);
           
            JMenuItem mt4=new JMenuItem("Update Employee");
           mt4.setMnemonic('U');
           mt4.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_U,ActionEvent.CTRL_MASK));
           mt4.addActionListener(this);
           
            JMenuItem mt5=new JMenuItem("Update Salary");
           mt5.setMnemonic('Y');
           mt5.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Y,ActionEvent.CTRL_MASK));
           mt5.addActionListener(this);
           
            JMenuItem mt6=new JMenuItem("Take Attendence");
           mt6.setMnemonic('A');
           mt6.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_A,ActionEvent.CTRL_MASK));
           mt6.addActionListener(this);
           
            JMenuItem mt7=new JMenuItem("List Attendence ");
           mt7.setMnemonic('T');
           mt7.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_T,ActionEvent.CTRL_MASK));
           mt7.addActionListener(this);
           
            JMenuItem mt8=new JMenuItem("Generate Payslip");
           mt8.setMnemonic('G');
           mt8.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_G,ActionEvent.CTRL_MASK));
           mt8.addActionListener(this);
           
            JMenuItem mt9=new JMenuItem("Exit");
           mt9.setMnemonic('X');
           mt9.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_X,ActionEvent.CTRL_MASK));
           mt9.addActionListener(this);
           
           mt1.setFont(f);
            mt2.setFont(f);
             mt3.setFont(f);
              mt4.setFont(f);
               mt5.setFont(f);
                mt6.setFont(f);
                 mt7.setFont(f);
                  mt8.setFont(f);
                   mt9.setFont(f);
                   
                   
                   m1.add(mt1);
                   m1.add(mt2);
                   m1.add(mt3);
                   
                   m2.add(mt4);
                   m2.add(mt5);
                   
                   m3.add(mt6);
                   m3.add(mt7);
                   m3.add(mt8);
                   
                   m4.add(mt9);
                   
                   mb.add(m1);
                   mb.add(m2);
                   mb.add(m3);
                   mb.add(m4);
                   
                   setJMenuBar(mb);
      }       
                   
        @Override
       public void actionPerformed(ActionEvent e)   
       {
           String comnd=e.getActionCommand();
            switch (comnd) {
                case "New Employee":
                    new new_employee().setVisible(true);
                    break;
                case "Salary":
                    new Salary().setVisible(true);
                    break;
                case "List employee":
                    new list_employee().setVisible(true);
                    break;
                case "Update Employee":
                    new update_employee().setVisible(true);
                    break;
                case "Update Salary":
                    new update_salary().setVisible(true);
                    break;
                case "Take Attendence":
                    new take_attendance().setVisible(true);
                    break;
                case "List Attendance":
                    new list_attendance().setVisible(true);
                    break;
                case "Exit":
                    System.exit(0);
                default:
                    JOptionPane.showMessageDialog(null,"sorry you press wrong button");
                    setVisible(false);
                    break;
            }
       }
           public static void main(String args[])
{
    new home_payroll().setVisible(true);
    }

  

    

}
    

    
    

